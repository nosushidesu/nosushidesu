# nosushidesu ♡ panduan website

## Isi folder

```
nosushidesu/
├── public/                  ← semua yang tampil di website
│   ├── index.html           ← halaman depan
│   ├── projects.html        ← arsip project per kategori
│   ├── events.html          ← daftar event + form RSVP + cek status
│   ├── admin.html           ← ruang admin (kelola event & peserta)
│   ├── data/site.js         ← ✿ EDIT DI SINI: nama, bio, link, teks
│   ├── data/projects.json   ← ✿ EDIT DI SINI: kategori & project
│   ├── img/                 ← taruh foto (avatar, jeno, jaemin, project)
│   └── assets/              ← desain (style.css) & animasi (deco.js)
├── functions/api/           ← "mesin" RSVP & waiting list
├── schema.sql               ← struktur database
└── wrangler.toml            ← setting Cloudflare
```

## Mau ganti apa → buka file mana

| Mau ganti | File | Caranya |
|---|---|---|
| Nama, bio, kartu profil, teks berjalan | `public/data/site.js` | ganti teks di dalam tanda kutip |
| Foto profil | `public/img/` + `site.js` | upload foto ke folder img, lalu isi `avatar: "/img/namafoto.jpg"` |
| Foto & catatan Jeno / Jaemin | `site.js` bagian `jeno` / `jaemin` | isi `photo` dan `note` |
| Link X / IG / kontak | `site.js` bagian `links` | ganti url-nya |
| Tambah / hapus project | `public/data/projects.json` | copy satu blok `{...}`, ganti isinya |
| Tambah kategori project | `projects.json` bagian `categories` | tambah satu baris, `id` tanpa spasi |
| Warna | `public/assets/style.css` paling atas (`:root`) | ganti kode hex |
| Event & RSVP | **tidak perlu edit file** | buka `/admin.html` |

Catatan: project berlabel **(contoh)** di `projects.json` itu placeholder, hapus/ganti dengan project aslimu.

## Setup pertama kali (sekali saja)

Karena ada RSVP, website ini perlu **Cloudflare Pages + D1**. Upload drag-and-drop di dashboard tidak menjalankan folder `functions`, jadi pakai salah satu cara ini:

**Cara A (disarankan): lewat GitHub**
1. Upload folder `nosushidesu` ke repo GitHub baru.
2. Cloudflare → Workers & Pages → Create → Pages → *Connect to Git* → pilih repo.
3. Build command: kosongkan. Build output directory: `public`.
4. Setiap kamu edit file di GitHub, website otomatis update.

**Cara B: lewat terminal**
```
npm install -g wrangler
wrangler login
wrangler pages deploy
```

**Lalu buat database:**
1. Cloudflare → Storage & Databases → D1 → *Create* → nama: `nosushidesu-db`.
2. Buka database → tab *Console* → copy-paste seluruh isi `schema.sql` → Execute.
3. Salin *Database ID*, tempel ke `wrangler.toml` (ganti `GANTI-DENGAN-DATABASE-ID-KAMU`).
4. Project Pages → Settings → Bindings → *Add* → D1 database → variable name `DB` → pilih `nosushidesu-db`.

**Lalu buat password admin:**
Project Pages → Settings → Variables and Secrets → *Add* → nama `ADMIN_KEY`, tipe **Secret**, isi password yang panjang. Deploy ulang sekali.

## Cara pakai RSVP & waiting list

1. Buka `namawebsitemu/admin.html`, masukkan `ADMIN_KEY`.
2. Klik **+ event baru**, isi judul, tanggal, lokasi, kuota slot, waiting list dibuka / tidak.
   - `hidden` = draft, belum muncul di website.
3. Link RSVP otomatis: `namawebsitemu/events.html?e=slug-event`. Ini yang kamu share di X.
4. Alur peserta:
   - Slot masih ada → langsung **terdaftar** + dapat kode tiket `JJ-XXXXXX`.
   - Slot penuh → masuk **waiting list** dengan nomor antrean.
   - 1 email cuma bisa daftar 1x per event.
5. Di admin:
   - **✖ batal** peserta terdaftar → orang pertama di waiting list **otomatis naik**.
   - Tambah kuota event → antrean juga otomatis naik.
   - **✔ hadir** untuk check-in di hari H (cari pakai kode tiket).
   - **download CSV** untuk rekap di Excel / Sheets.
6. Peserta bisa cek status sendiri di halaman events pakai kode tiketnya.
7. Event selesai → ubah status ke `done`, pindah ke "event yang sudah lewat".
